package json;

public interface None {
    /**
     * Negative One
     */
    public static final int none = -1;

}
