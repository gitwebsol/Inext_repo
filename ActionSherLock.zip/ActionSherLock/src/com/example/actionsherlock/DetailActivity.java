package com.example.actionsherlock;

import java.io.ByteArrayOutputStream;

import com.example.actionsherlock.utils.AppData;
import com.example.actionsherlock.utils.ItemData;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class DetailActivity extends Activity {

	// action bar
	private ActionBar actionBar;
	TextView txt;
	Button AddTo_inventory;
	DataBaseHandler db;
	byte[] data;
	Bitmap bm ;
	
	String image_url;
	Contact con;
	AppData appData;
	ItemData itemData;

	// Refresh menu item
	private MenuItem refreshMenuItem;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_detail);

		appData = new AppData(this);
		
		actionBar = getActionBar();
		con = new Contact();

		// Enabling Back navigation on Action Bar icon
		actionBar.setDisplayHomeAsUpEnabled(true);

		// Hide the action bar title

		actionBar.setDisplayShowTitleEnabled(true);

		// Enabling Spinner dropdown navigation
		actionBar.setNavigationMode(ActionBar.DISPLAY_SHOW_TITLE);

		// actionBar.setNavigationMode(R.string.app_name);
		actionBar.setTitle("Inventory");

		final Intent i = getIntent();
		txt = (TextView) findViewById(R.id.txtvw);
		bm = i.getParcelableExtra("image");
		txt.setText(i.getStringExtra("title"));
		ImageView imgVW = (ImageView) findViewById(R.id.imgvw);
		image_url = i.getStringExtra("image");
		
	
		
		imgVW.setImageBitmap(bm);
		db = new DataBaseHandler(getApplicationContext());
		AddTo_inventory = (Button) findViewById(R.id.addToInventry);
		
		AddTo_inventory.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				// convert bitmap to byte
					Bitmap bmp = i.getParcelableExtra("image");
					ByteArrayOutputStream bos = new ByteArrayOutputStream();
					bmp.compress(Bitmap.CompressFormat.PNG, 100, bos);
					data = bos.toByteArray();
					itemData = new ItemData();
					
					itemData.title = txt.getText().toString();
					itemData.image = data;
					
					if(!appData.isPresent(txt.getText().toString())){
					appData.addItem(itemData);
					
					Toast.makeText(getApplicationContext(), "Added Item is:-"+" "+txt.getText().toString(),
							Toast.LENGTH_SHORT).show();
					} else{
						Toast.makeText(getApplicationContext(), "Item already added:-"+" "+txt.getText().toString(),
								Toast.LENGTH_SHORT).show();
					}
			}
		});

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.detail, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Take appropriate action for each action item click
		switch (item.getItemId()) {
		case android.R.id.home:
			// search action
			finish();
			return true;

		default:
			return super.onOptionsItemSelected(item);
		}

	}
}
