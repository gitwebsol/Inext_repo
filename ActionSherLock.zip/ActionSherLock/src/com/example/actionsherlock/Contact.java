package com.example.actionsherlock;

public class Contact {

	// private variables
	int _id;
	String _title;
	byte[] _image;

	// Empty constructor
	public Contact() {

	}

	// constructor
	public Contact(int keyId, String title, byte[] image, String url) {
		this._id = keyId;
		this._title = title;
		this._image = image;

	}

	// constructor
	public Contact(String title, byte[] image, String url) {
		this._title = title;
		this._image = image;

	}

	// getting ID
	public int getID() {
		return this._id;
	}

	// setting id
	public void setID(int keyId) {
		this._id = keyId;
	}

	// getting name
	public String gettitle() {
		return this._title;
	}

	// setting name
	public void settitle(String title) {
		this._title = title;
	}

	// getting phone number
	public byte[] getImage() {
		return this._image;
	}

	// setting phone number
	public void setImage(byte[] image) {
		this._image = image;
	}

}
