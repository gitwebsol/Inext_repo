package com.example.actionsherlock.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.app.Application;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.util.Log;

public class AppDelegate extends Application {

	public long lastUpdated;
	public static String opened;
	public String[] tables = new String[10];
	public static String appPath;
	public static String basePath;

	private void setLastUpdated() {
		lastUpdated = System.currentTimeMillis() / 1000;
		SharedPreferences preferences = getSharedPreferences(
				"heritageLastOpened", MODE_PRIVATE);
		SharedPreferences.Editor editor = preferences.edit();
		editor.putLong("heritageLastOpened", lastUpdated);
		editor.commit();
	}

	private void setOpened() {
		SharedPreferences preferences = getSharedPreferences("heritageOpened",
				MODE_PRIVATE);
		SharedPreferences.Editor editor = preferences.edit();
		editor.putString("heritageOpened", "yes");
		editor.commit();
	}

	@Override
	public void onCreate() {
		super.onCreate();

		
		SharedPreferences preferences = getSharedPreferences(
				"heritageLastOpened", MODE_PRIVATE);
		lastUpdated = preferences.getLong("heritageLastOpened", 0);
		SharedPreferences preferences1 = getSharedPreferences("heritageOpened",
				MODE_PRIVATE);
		opened = preferences1.getString("heritageOpened", "no");
		Log.d("appdelegate opened: ", opened);
		if (opened.equals("no")) {
			Log.d("AppDelegate1111", "Brand New!");
			Log.d("copy", "trying to copy");
			try {
				insertDatabase();
				setOpened();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Opened : " + opened);
		if (opened.equals("yes")) {

			if (lastUpdated < (System.currentTimeMillis() / 1000 - 86400)) {

			} else {
				Log.d("AppDelegate", "All Up To Date");
			}
		}
	}

	public void insertDatabase() throws IOException {
		Log.d("Copy", "Started");
		AssetManager assetManager = getAssets();
		// Open your local db as the input stream
		InputStream fis = assetManager.open("actiondata");
		String outDirectory = "/data/data/com.example.actionsherlock/databases";
		String outFileName = "/data/data/com.example.actionsherlock/databases/actiondata";

		File dir = new File(outDirectory);
		dir.mkdirs();

		OutputStream output = new FileOutputStream(outFileName);
		byte[] buffer = new byte[1024];
		int length;
		while ((length = fis.read(buffer)) > 0) {
			output.write(buffer, 0, length);
		}

		output.flush();
		output.close();
		fis.close();
		Log.d("Copy", "Finished");

	}
}
