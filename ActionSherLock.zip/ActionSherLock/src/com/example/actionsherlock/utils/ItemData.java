package com.example.actionsherlock.utils;


public class ItemData {
	public String title, id;
//	public String image;
	public byte[] image;
}
