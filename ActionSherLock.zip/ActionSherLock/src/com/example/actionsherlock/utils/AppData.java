package com.example.actionsherlock.utils;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.http.util.ByteArrayBuffer;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class AppData extends SQLiteOpenHelper {


	private static final int DATABASE_VERSION = 1;
	private static final String DATABASE_NAME = "actiondata";

	public AppData(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	public AppData(Context context, String name, CursorFactory factory,
			int version) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {

	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
	}

	public void deleteMenuImages() {
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete("menuimages", null, null);
	}

	// ------------------ap_news---------------------------

	public void addItem(ItemData theObject) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();

		values.put("id", theObject.id);
		values.put("Title", theObject.title);
		values.put("Image", theObject.image);

		String countQuery = "SELECT * FROM inventory_insert WHERE id=" + theObject.id;
		Cursor cursor = db.rawQuery(countQuery, null);
		int count = cursor.getCount();
		cursor.close();
		if (count > 0) {
			db.update("inventory_insert", values, "id" + " = ?",
					new String[] { String.valueOf(theObject.id) });
			Log.d("UPDATE", "UPDATE ACCOM TYPE");
		} else {
			db.insert("inventory_insert", null, values);
			Log.d("INSERT", "INSERT ACCOM TYPE");
		}
		// db.close();
	}

	public List<HashMap<String, Object>> getItems() {
		List<HashMap<String, Object>> l_Select =  new ArrayList<HashMap<String,Object>>();
		String selectQuery = "SELECT * FROM `inventory_insert`";
		SQLiteDatabase db = this.getWritableDatabase();

		 Cursor cursor = db.rawQuery(selectQuery, null);

		if (cursor.moveToFirst()) {
			
			
			do {
				HashMap<String, Object> hs = new HashMap<String, Object>();
				hs.put("Title", cursor.getString(1));
				hs.put("image", cursor.getBlob(2));
				l_Select.add(hs);
			} while (cursor.moveToNext());
		}

		return l_Select;
	}

	public void deleteItems(String title) {
		SQLiteDatabase db = this.getWritableDatabase();
		String where = "Title = ?";
		String[] whereArgs = { title };
		db.delete("inventory_insert", where, whereArgs);
	}
	
	private byte[] getLogoImage(String url) {
		try {
			URL imageUrl = new URL(url);
			URLConnection ucon = imageUrl.openConnection();

			InputStream is = ucon.getInputStream();
			BufferedInputStream bis = new BufferedInputStream(is);

			ByteArrayBuffer baf = new ByteArrayBuffer(500);
			int current = 0;
			while ((current = bis.read()) != -1) {
				baf.append((byte) current);
			}

			return baf.toByteArray();
		} catch (Exception e) {
			Log.d("ImageManager", "Error: " + e.toString());
		}
		return null;
	}
	
	public boolean isPresent(String title){

		SQLiteDatabase db = this.getWritableDatabase();
		String selectQuery = "SELECT * FROM `inventory_insert` "+" where Title = '" +title + "'" ;
		Log.e("selectQuery>"+selectQuery, "");
		Cursor cursor = db.rawQuery("SELECT * FROM `inventory_insert`" + " where Title = '" +title + "'" , null);
		Log.e("cursor.getCount()===>"+cursor.getCount(), "");
		if(cursor.getCount()>0){
		return true;
		}
		return false;
		}

	
	
}
