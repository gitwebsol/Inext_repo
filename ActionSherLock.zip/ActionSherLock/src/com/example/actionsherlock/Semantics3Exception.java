package com.example.actionsherlock;

public class Semantics3Exception extends RuntimeException {
	public Semantics3Exception(String code,String message) {
		super(message);
	}
}
