package com.example.actionsherlock;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class NewAdapter extends BaseAdapter {

	private Activity activity;

	private static LayoutInflater inflater = null;
	ArrayList<String> aTitle = new ArrayList<String>();
//	ArrayList<Bitmap> aImage = new ArrayList<Bitmap>();
//	ArrayList<String> aImage = new ArrayList<String>();
//	ArrayList<byte[]> al_byte = new ArrayList<byte[]>();
//	public ImageLoader imageLoader;
	//Bitmap bitmap;

	// aArrayList<Integer> id = new ArrayList<Integer>();

	// public ImageLoader imageLoader;
	
	//,	ArrayList<String> membername, ArrayList<byte[]> al_byte

	public NewAdapter(Activity a, ArrayList<String> counter) {
		this.activity = a;
		this.aTitle = counter;
//		this.aImage = membername;
//		this.al_byte = al_byte;
		
		inflater = (LayoutInflater) activity
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	//	imageLoader=new ImageLoader(activity.getApplicationContext());

	}

	public Object getItem(int position) {
		return position;
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		View vi = convertView;
		if (convertView == null)
			vi = inflater.inflate(R.layout.list_item, null);

//		if(al_byte == null){
//		
//		TextView member_name = (TextView) vi.findViewById(R.id.product_name);
//		ImageView btn_groupName = (ImageView) vi.findViewById(R.id.imageView_action);
//		member_name.setText(aTitle.get(position));
//		imageLoader.DisplayImage(aImage.get(position), btn_groupName);
////		btn_groupName.setImageBitmap(aImage.get(position));
//		}
//		else{
			TextView member_name = (TextView) vi.findViewById(R.id.product_name);
	//		ImageView btn_groupName = (ImageView) vi.findViewById(R.id.imageView_action);
			member_name.setText(aTitle.get(position));
			Log.e("Tittle in ADpter:->", aTitle.get(position));
			
//			bitmap = BitmapFactory.decodeByteArray(al_byte.get(position), 0,
//					al_byte.get(position).length);
//
//			btn_groupName.setImageBitmap(bitmap);
			
			return vi;
		}

	


	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return aTitle.size();
	}
}
