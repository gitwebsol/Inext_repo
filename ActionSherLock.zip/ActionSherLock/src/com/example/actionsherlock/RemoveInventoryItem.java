package com.example.actionsherlock;

import com.example.actionsherlock.utils.AppData;

import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class RemoveInventoryItem extends Activity {
	
	private ActionBar actionBar;
	TextView tv;
	ImageView iv;
	Button remove_Item;
	String title;
	byte[] image;
	DataBaseHandler db;
	Bitmap bitmap;
	AppData appData;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.remove_inventory_item);
		tv = (TextView) findViewById(R.id.txtvw);
		iv = (ImageView) findViewById(R.id.imgvw);
		remove_Item = (Button) findViewById(R.id.removeToInventry);
		
		Intent in = getIntent();
		title = in.getStringExtra("title");
		image = in.getByteArrayExtra("image");
		
		appData = new AppData(this);
		
		tv.setText(title);
		
		bitmap = BitmapFactory.decodeByteArray(image, 0,
				image.length);
		
		iv.setImageBitmap(bitmap);
		
		actionBar = getActionBar();

		// Enabling Back navigation on Action Bar icon
		actionBar.setDisplayHomeAsUpEnabled(true);

		// Hide the action bar title

		actionBar.setDisplayShowTitleEnabled(true);

		// Enabling Spinner dropdown navigation
		actionBar.setNavigationMode(ActionBar.DISPLAY_SHOW_TITLE);

		// actionBar.setNavigationMode(R.string.app_name);
		actionBar.setTitle("Inventory");
		
		db = new DataBaseHandler(getApplicationContext());
		
		remove_Item.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				appData.deleteItems(title);
				Toast.makeText(RemoveInventoryItem.this, "Item removed:-"+" "+title, Toast.LENGTH_SHORT).show();
				finish();
				
			}
		});
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.remove_inventory_item, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Take appropriate action for each action item click
		switch (item.getItemId()) {
		case android.R.id.home:
			// search action
			finish();
			return true;

		default:
			return super.onOptionsItemSelected(item);
		}

	}
}
