package com.example.actionsherlock;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import oauth.signpost.exception.OAuthCommunicationException;
import oauth.signpost.exception.OAuthExpectationFailedException;
import oauth.signpost.exception.OAuthMessageSignerException;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import json.JSONArray;
import json.JSONException;
import json.JSONObject;

import com.example.actionsherlock.utils.AppData;
import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Filterable;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.SearchView.OnQueryTextListener;

public class MainActivity extends Activity implements OnQueryTextListener {

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		
	getItems();
	}

	// action bar
	private ActionBar actionBar;

	// Refresh menu item
	private MenuItem refreshMenuItem;
	GroupCustomAdapter adapterI;

	// List view
	private ListView lv, lv1;

	// Listview Adapter
	ArrayAdapter<String> adapter;
	String responseString;
	JSONArray jsonarray;
	JSONObject jsonObject;
	String name, image;
	ArrayList<String> title, title1, image_array;
	ArrayList<Bitmap> image_array1;
	ProgressDialog pg;
	DataBaseHandler db;
	AppData appData;
	Contact con;
	NewAdapter newAdapter;
	ArrayList<String> title2;
	ArrayList<byte[]> arr_byte;

	private ArrayList<String> array_sort;
	int textlength = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		appData = new AppData(this);

		db = new DataBaseHandler(MainActivity.this);

		lv = (ListView) findViewById(R.id.list_view);
		lv1 = (ListView) findViewById(R.id.list_view1);
		actionBar = getActionBar();
		con = new Contact();

		// Hide the action bar title
		actionBar.setDisplayShowTitleEnabled(true);

		// Enabling Spinner dropdown navigation
		actionBar.setNavigationMode(ActionBar.DISPLAY_SHOW_TITLE);

		actionBar.setTitle("Inventory");
		lv.setVisibility(View.GONE);
		lv1.setVisibility(View.VISIBLE);

		getItems();

		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub

				Intent intent = new Intent(MainActivity.this,
						DetailActivity.class);
				intent.putExtra("title", title.get(position));
				intent.putExtra("image", image_array1.get(position));
				startActivity(intent);

			}
		});

		lv1.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				Intent in = new Intent(MainActivity.this,
						RemoveInventoryItem.class);
				in.putExtra("title", title2.get(position));
				in.putExtra("image", arr_byte.get(position));
				startActivity(in);
			}
		});

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main_actions, menu);

		// Associate searchable configuration with the SearchView
		SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
		SearchView searchView = (SearchView) menu.findItem(R.id.action_search)
				.getActionView();
		searchView.setSearchableInfo(searchManager
				.getSearchableInfo(getComponentName()));
		searchView.setOnQueryTextListener(this);
		return true;
	}

	/**
	 * On selecting action bar icons
	 * */
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Take appropriate action for each action item click
		switch (item.getItemId()) {
		case R.id.action_search:
			// search action
			return true;
		case R.id.action_refresh:
			// refresh
			refreshMenuItem = item;
			// load the data from server
			new SyncData().execute();
			return true;
		case R.id.action_help:
			// help action
			return true;
		case R.id.action_check_updates:
			// check for updates action
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	/**
	 * Async task to load the data from server
	 * **/
	private class SyncData extends AsyncTask<String, Void, String> {
		@Override
		protected void onPreExecute() {
			// set the progress bar view
			refreshMenuItem.setActionView(R.layout.action_progressbar);

			refreshMenuItem.expandActionView();
		}

		@Override
		protected String doInBackground(String... params) {
			// not making real request in this demo
			// for now we use a timer to wait for sometime
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			refreshMenuItem.collapseActionView();
			// remove the progress bar view
			refreshMenuItem.setActionView(null);
		}
	}

	@Override
	public boolean onQueryTextChange(String newText) {
		// TODO Auto-generated method stub

		if (newText.equals("")) {
			lv.setAdapter(null);
			lv.setVisibility(View.GONE);
			lv1.setVisibility(View.VISIBLE);

		getItems();
			// adapterI.notifyDataSetChanged();
		}
		return false;
	}

	public void AppendList(ArrayList<String> str, ArrayList<String> ia) {
		lv.setAdapter(new GroupCustomAdapter(MainActivity.this, str, ia, null));
	}

	@Override
	public boolean onQueryTextSubmit(String query) {
		// TODO Auto-generated method stub
		Log.e("Msg1", query);
		lv.setVisibility(View.VISIBLE);
		// ((Filterable) MainActivity.this.adapterI).getFilter().filter(query);

		new BackgroundTask().execute(query);

		return false;
	}

//	public class FetchListInfo extends AsyncTask<String, Void, String> {
//
//		@Override
//		protected void onPreExecute() {
//			// TODO Auto-generated method stub
//			super.onPreExecute();
////			
////			if(adapterI!=null){
////				adapterI.
////			}
//
//			image_array = new ArrayList<String>();
//			title = new ArrayList<String>();
//			image_array1 = new ArrayList<Bitmap>();
//			title1 = new ArrayList<String>();
//
//			pg = new ProgressDialog(MainActivity.this);
//			pg.setMessage("Loading..");
//			// pg.setCancelable(false);
//			pg.show();
//		}
//
//		@Override
//		protected void onPostExecute(String result) {
//			// TODO Auto-generated method stub
//			super.onPostExecute(result);
//			lv.setVisibility(View.VISIBLE);
//			lv1.setVisibility(View.GONE);
//
//			adapterI = new GroupCustomAdapter(MainActivity.this, title,
//					image_array, null);
//			lv.setAdapter(adapterI);
//
//			if (result.equals("complete"))
//				pg.dismiss();
//
//		}
//
//		@Override
//		protected String doInBackground(String... params) {
//			// TODO Auto-generated method stub
//
//			// TODO Auto-generated method stub
//
//			HttpClient httpclient = new DefaultHttpClient();
//
//			System.out.println("USER ID IN CONATCT SCREEN:---- :" + params[0]);
//			try {
//				// Add your data
//				// http://demo.inextsolutions.com/calendar/view_user_profile.php?userid=1
//
//				String url = "http://us.api.invisiblehand.co.uk/v1/products?query="
//						+ params[0]
//						+ "&app_id=3257debb&app_key=96b80cd5efede94308be1562b5529ed0";
//
//				System.out.println("GROUP URL:---- :" + url);
//				HttpGet httppost = new HttpGet(url);
//
//				org.apache.http.client.ResponseHandler<String> responseHandler = new BasicResponseHandler();
//				String response = httpclient.execute(httppost, responseHandler);
//
//				// This is the response from a php application
//				responseString = response.trim();
//
//				jsonObject = new JSONObject(responseString);
//
//				jsonarray = jsonObject.getJSONArray("results");
//
//				for (int i = 0; i < jsonarray.length(); i++) {
//					JSONObject jobj = jsonarray.getJSONObject(i);
//
//					if (jsonarray.getJSONObject(i).has("best_page")) {
//
//						JSONObject jsonObject = jobj.getJSONObject("best_page");
//
//						name = jsonObject.getString("title");
//
//						image = jsonObject.getString("image_url");
//
//						Bitmap bitmap = Bitmap12.getBitmapFromURL(image);
//
//						title.add(name);
//						image_array.add(image);
//						image_array1.add(bitmap);
//						Log.e("Title", name);
//					}
//				}
//
//			} catch (ClientProtocolException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} catch (JSONException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			return "complete";
//
//		}
//
//	}

	void getItems() {
		title2 = new ArrayList<String>();
		arr_byte = new ArrayList<byte[]>();

		List<HashMap<String, Object>> ls = appData.getItems();
	//	ArrayList<String> ls = appData.getItems();
		

		for (HashMap<String, Object> hs : ls) {
			String title = (String) hs.get("Title");
			Object image = hs.get("image");

			Log.e("TITLE:---->>>>", title);

			title2.add(title);
			arr_byte.add((byte[]) image);

			Log.e("IMAGE:---->>>>", "" + image);

		}

		adapterI = new GroupCustomAdapter(this, title2, null, arr_byte);
		lv1.setAdapter(adapterI);
	}
	
	class BackgroundTask extends AsyncTask<String, Void, String>{
		
		

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			
//			if(adapterI!=null)
//			clearAdapter();
			
			image_array = new ArrayList<String>();
			title = new ArrayList<String>();
			image_array1 = new ArrayList<Bitmap>();
			title1 = new ArrayList<String>();

			pg = new ProgressDialog(MainActivity.this);
			pg.setMessage("Loading..");
			pg.setCancelable(false);
			pg.show();
			
			
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			
			pg.dismiss();
			
			lv.setVisibility(View.VISIBLE);
			lv1.setVisibility(View.GONE);

			adapterI = new GroupCustomAdapter(MainActivity.this, title,
					image_array, null);
			lv.setAdapter(adapterI);

//			if (result.equals("complete"))
				
			
			//Log.e("Titles in on post : ", ""+title);
			
			
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			
			Products products = new Products(
					"SEM3F5FE8F99C5A1531A11D8C24B30457286",
					"YTczZjUyMTc0MTA4Mzg3NmUxZGE3MjNlYWQ5NGQ4MDg");

			products
					.productsField("brand", params[0]);

			JSONObject results = null;
			
						
			
			try {
				results = products.getProducts();
			} catch (OAuthMessageSignerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (OAuthExpectationFailedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (OAuthCommunicationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Results : "+results);

			JSONArray array = results.getJSONArray("results");
			JSONObject job = null;
			for (int i = 0; i < array.length(); i++) {
				job = (JSONObject) array.get(i);
				
				String name = job.getString("name");
//				String image = "http://www.ufcqatar.com/coming_soon.jpg";
				
				JSONArray job1 = job.getJSONArray("images");
				
				String image_url = job1.getString(0);
				
				Bitmap bitmap = Bitmap12.getBitmapFromURL(image_url);
				image_array.add(image_url);
				image_array1.add(bitmap);
				Log.e("Images :---->", image_url);
				title.add(name);
//				image_array.add(image);
//				image_array1.add(bitmap);
				
				
			}
			
			
			return results.toString();
		}
		
	}
	
	void clearAdapter(){
		image_array.clear();
		title.clear();
		image_array1.clear();
		title1.clear();
		
		adapterI.notifyDataSetChanged();
	}
	
	
}
